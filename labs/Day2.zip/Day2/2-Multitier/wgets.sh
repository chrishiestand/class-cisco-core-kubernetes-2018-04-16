wget https://kubernetes.io/docs/tutorials/stateless-application/guestbook/redis-master-deployment.yaml
wget https://kubernetes.io/docs/tutorials/stateless-application/guestbook/redis-master-service.yaml
wget https://kubernetes.io/docs/tutorials/stateless-application/guestbook/redis-slave-deployment.yaml
wget https://kubernetes.io/docs/tutorials/stateless-application/guestbook/redis-slave-service.yaml
wget https://kubernetes.io/docs/tutorials/stateless-application/guestbook/frontend-deployment.yaml
wget https://kubernetes.io/docs/tutorials/stateless-application/guestbook/frontend-service.yaml